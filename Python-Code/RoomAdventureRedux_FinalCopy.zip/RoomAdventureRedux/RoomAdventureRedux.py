###########################################################################################
# Name: Jordan Fergurson
# Date: July 23,2018
# Description: Room Adventure...Reloaded. Consisting of 7 Rooms, 2 possible
# death scenes.
# 
###########################################################################################

from Tkinter import *
import random


# the room class
# note that this class is fully implemented with dictionaries as illustrated in the lesson "More on Data Structures"
class Room(object):
    # the constructor
    def __init__(self, name, image):
        # rooms have a name, an image (the name of a file), exits (e.g., south), exit locations
        # (e.g., to the south is room n), items (e.g., table), item descriptions (for each item),
        # and grabbables (things that can be taken into inventory)
        self.name = name
        self.image = image
        self.exits ={}
        self.items = {}
        self.grabbables = []

    # getters and setters for the instance variables
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value

    @property
    def image(self):
        return self._image

    @image.setter
    def image(self, value):
        self._image = value

    @property
    def exits(self):
        return self._exits

    @exits.setter
    def exits(self, value):
        self._exits = value

    @property
    def items(self):
        return self._items

    @items.setter
    def items(self, value):
        self._items = value

    @property
    def grabbables(self):
        return self._grabbables

    @grabbables.setter
    def grabbables(self, value):
        self._grabbables = value

    # adds an exit to the room
    # the exit is a string (e.g., north)
    # the room is an instance of a room
    def addExit(self, exit, room):
        # append the exit and room to the appropriate dictionary
        self._exits[exit] = room

    # adds an item to the room
    # the item is a string (e.g., table)
    # the desc is a string that describes the item (e.g., it is made of wood)
    def addItem(self, item, desc):
        # append the item and description to the appropriate dictionary
        self._items[item] = desc

    # adds a grabbables item to the room
    # the item is a string (e.g., key)
    def addGrabbables(self, item):
        # append the item to the list
        self._grabbables.append(item)

    # removes a grabbables item from the room
    # the item is a string (e.g., key)
    def delGrabbables(self, item):
        # remove the item from the list
        self._grabbables.remove(item)

    # returns a string description of the room
    def __str__(self):
        # first, the room name
        s = "You are in {}.\n".format(self.name)

        # next, the items in the room
        s += "You see: "
        for item in self.items.keys():
                s += item + " "
        s += "\n"

        # next, the exits from the room
        s += "Exits: "
        for exit in self.exits.keys():
                s += exit + " "

        return s

# the game class
# inherits from the Frame class of Tkinter
class Game(Frame):

    # the constructor
    def __init__(self, parent):

        # call the constructor in the superclass
        Frame.__init__(self, parent)


    # creates the rooms
    def createRooms(self):

        #### Room 1 ####
        R1 = Room("Room 1", "Room1Initial.gif")
        R1_1 = Room("Room 1", "Room1LookFramedPicture.gif")
        R1_2 = Room("Room 1", "Room1LooktableWithkey.gif")
        R1_3 = Room("Room 1", "Room1Initial_keyTaken.gif")
        R1_4 = Room("Room 1", "Room1LooktableWithoutkey.gif")

        #### Room 2 ####
        R2 = Room("Room 2", "Room2Initial.gif")
        R2_1 = Room("Room 2", "Room2Lookbar.gif")
        R2_2 = Room("Room 2", "Room2Lookdesk.gif")
        R2_3 = Room("Room 2", "Room2LookRig.gif")

        #### Room 3 ####
        R3 = Room("Room 3", "Room3Initial.gif")
        R3_1 = Room("Room 3", "Room3HiddenTreasure.gif")
        R3_2 = Room("Room 3", "Room3Solaire_PraiseTheSunForTheWin_2D.gif")

        #### Room 4 ####
        R4 = Room("Room 4", "Room4Initial_The_Lab.gif")
        R4_1 = Room("Room 4", "Room4Looktable.gif")
        R4_2 = Room("Room 4", "Room4Lookcages.gif")
        R4_3 = Room("Room 4", "Room4LookBookshelf.gif")
        R4_4 = Room("Room 4", "Room4LookBookshelf_TakeInkRibbon.gif")
        R4_5 = Room("Room 4", "Room4_Survived_BokcaseMoved.gif")

        #### Room 5 ####
        R5 = Room("Room 5", "Room5Initial_Layout.gif")
        R5_1 = Room("Room 5", "Room5_Greet_Dog.gif")
        R5_2 = Room("Room 5", "Room5_ITEMPOSSESED_ESTUSREWARD.gif")
        R5_3 = Room("Room 5", "Room5_NOITEM.gif")
        R5_4 = Room("Room 5", "Room5_Didn'tTakeEstus.gif")
        R5_5 = Room("Room 5", "Room5_EstusTakn_Survived.gif")
                

        #### Room 6 ####
        R6 = Room("Room 6", "Room6Initial.gif")
        R6_1 = Room("Room 6", "Room6_Looktable_Bones.gif")
        R6_2 = Room("Room 6", "Room6_Looktable_BoneTaken.gif")
        R6_3 = Room("Room 6", "Room6_MushroomHouse_Randomizer.gif")
        R6_4 = Room("Room 6", "Room6_painting.gif")

        #### Room 7
        R7 = Room("Room 7", "Room7Initial.gif")
        R7_1 = Room("Room 7", "Room7_vial.gif")
        R7_2 = Room("Room 7", "Room7_Biohazard_barrel.gif")
        R7_3 = Room("Room 7", "Room7_vial_Taken.gif")
        R7_4 = Room("Room 7", "Room7Initial_vialTaken.gif")

        ### Death Scenes ###
        DeathRoom1 = Room("WTF", "Youdied!Sif.gif")################################################################
        DeathRoom2 = Room("WTF", "BiohazardDeath_WTF.gif")
        #DeathRoom3 = 


        # Add Exits to main Rooms 
        R1.addExit("north", R2)
        R1.addExit("east", R3)

        R2.addExit("upstairs", R6)
        R2.addExit("south", R1)

        R3.addExit("west", R1)
        R3.addExit("north", R4)

        R4.addExit("south", R3)

        R5.addExit("west", R4)

        R6.addExit("downstairs", R2)
        R6.addExit("east", R7)

        R7.addExit("west", R6)


        # Add grabbables to Main Room 
        R1.addGrabbables("key")
        R1_2.addGrabbables("key")

        R4.addGrabbables("ink_ribbon")
        R4_3.addGrabbables("ink_ribbon")
        

        R5_2.addGrabbables("potion")
        

        R6.addGrabbables("biscuits")
        R6_1.addGrabbables("biscuits")

        R7.addGrabbables("vial")
        R7_1.addGrabbables("vial")

        # Add Items and descriptions to Main Room
        R1.addItem("painting", "It's a nice framed painting of a moose hunt by a pack of wolves")
        R1_3.addItem("painting", "It's a nice framed painting of a moose hunt by a pack of wolves")
        R1.addItem("table", "It's just a table. There is a small key on it, I wonder if that would be useful...")
        R1_3.addItem("table", "It's a table.")
        R1_2.addItem("key", "It's a key.")



        R2.addItem("bar", "It's fully stocked. I need this in my office...")
        R2.addItem("desk", "There is an old book and some notes here. Why does that tube of green stuff look familiar...")
        R2.addItem("rig", "It's a nice setup. Likely for some hardcore gamer.")

        R3.addItem("chest", "It's a treasure  chest. Unfortunately it's locked.")

        R4.addItem("table", "There are some medical tools lying on it. Is that blood...!?")
        R4.addItem("cages", "These aren't for your average lab rat.")
        R4.addItem("bookshelf", "It's full of untitled books and notes. There is an ink ribbon on it.")
        R4_3.addItem("bookshelf", "It's full of untitled books and notes. There is an ink ribbon on it.")
        R4_4.addItem("bookshelf", "It's full of untitled books and notes.")



        #R5.addItem(
        R5.addItem("dog", "It's small and kind of creepy, just staring like that.")
        R5_2.addItem("potion", "I wonder what this does")

        R6.addItem("nightstand", "There are dog treats sitting here. I wonder where the dog is.")
        #R1.addItem
        R6.addItem("artwork", "It's a painting. I like the colors.")
        R6.addItem("playhouse", "It's shaped like a mushroom. It looks like a person could just fit in here.")
        R6_1.addItem("biscuits", "Don't those look delicious?")
        R7.addItem("table", "It's made of stone. I wonder what sort of brew is in this vial.")
        R7.addItem("barrel", "Why is this here? That looks like a kind of Biohazard symbol...")
        R7_1.addItem("vial", "I bet drinking this would be a very bad idea")

        ##### Add Exits to Dummy Rooms#####
        
        # R1_1 --> [Look at painting], R1_2 --> [Look table with key] R1_3 --> [key Taken]
        # R1_4 --> [Look table, No key]
        R1_1.addExit("back", R1)
        R1_2.addExit("back", R1)
        R1_3.addExit("north", R2)
        R1_3.addExit("east", R3)
        R1_4.addExit("back", R1)

        # R2_1 --> [Look bar], R2_2 --> [Look desk], R2_3 --> [Look Rig]
        R2_1.addExit("back", R2)
        R2_2.addExit("back", R2)
        R2_3.addExit("back", R2)

        # R3_1 --> [Look chest], R3_2 --> [Solaire FTW]
        R3_1.addExit("back", R3)

        # R4_1 --> [Look table], R4_2 --> [Look cages], R4_3 --> [Look Bookshelf, Ink Ribbon]
        # R4_5 --> [Bookcase Moved, Survived], R4_4 --> [Look Bookshelf, No Ink]
        R4_1.addExit("back", R4)
        R4_2.addExit("back", R4)
        R4_3.addExit("back", R4)
        R4_5.addExit("south", R3)
        R4_5.addExit("east", R5) # Only if Bookshelf moved

        # R5
        R5_1.addExit("back", R5)
        R5_2.addExit("back", R5)
        R5_4.addExit("west", R5)
        R5_5.addExit("west", R5)

        # R6
        R6_1.addExit("back", R6)
        R6_2.addExit("back", R6)
        R6_3.addExit("back", R6) # Add Randomizer Code for Mushroom
        R6_4.addExit("back", R6)

        # R7
        R7_1.addExit("back", R7)
        R7_2.addExit("back", R7)
        R7_3.addExit("back", R7)
        R7_4.addExit("west", R6)

        #set room 1 as the current room at the beginning of the game
        Game.currentRoom = R1
        

        #Set a list of variables that can point to different rooms and change their values#####################POINTERS

        #Room1
        Game.R1 = R1
        Game.R1_1 = R1_1
        Game.R1_2 = R1_2
        Game.R1_3 = R1_3
        Game.R1_4 = R1_4

        #Room2
        Game.R2 = R2
        Game.R2_1 = R2_1
        Game.R2_2 = R2_2
        Game.R2_3 = R2_3
        
        #Room3
        Game.R3 = R3
        Game.R3_1 = R3_1
        Game.R3_2 = R3_2

        #Room4
        Game.R4 = R4
        Game.R4_1 = R4_1
        Game.R4_2 = R4_2
        Game.R4_3 = R4_3
        Game.R4_4 = R4_4
        Game.R4_5 = R4_5

        #Room5
        Game.R5 = R5
        Game.R5_1 = R5_1
        Game.R5_2 = R5_2
        Game.R5_3 = R5_3

        #Room6
        Game.R6 = R6
        Game.R6_1 = R6_1
        Game.R6_2 = R6_2
        Game.R6_3 = R6_3
        Game.R6_4 = R6_4

        #Room7
        Game.R7 = R7
        Game.R7_1 = R7_1
        Game.R7_2 = R7_2
        Game.R7_3 = R7_3
        Game.R7_4 = R7_4
        
        

        # Death Scene 1(Sif)
        Game.DeathRoom1 = DeathRoom1

        #death room 2(vial)
        Game.DeathRoom2 = DeathRoom2

        #death room 3 (potion)
        #Game.deathRoom3 = deathRoom3

        #initialize the players inventory
        Game.inventory = []
                
    # sets up the GUI
    def setupGUI(self):

        # organize the GUI
        self.pack(fill=BOTH, expand=1)

        # setup the player input at the bottom of the GUI
        # the widget is a Tkinter Entry
        # set its background to white and bind the return key to the
        # function process in the class
        # push it to the bottom of the GUI and let it fill
        # horizontally
        # give it focus so the player doesn't have to click on it
        Game.player_input = Entry(self, bg="white")
        Game.player_input.bind("<Return>", self.process)
        Game.player_input.pack(side=BOTTOM, fill=X)
        Game.player_input.focus()

        # setup the image to the left of the GUI
        # the widget is a Tkinter Label
        # don't let the image control the widget's size
        img = None
        Game.image = Label(self, width=WIDTH / 2, image=img)
        Game.image.image = img
        Game.image.pack(side=LEFT, fill=Y)
        Game.image.pack_propagate(False)

        # setup the text to the right of the GUI
        # first, the frame in which the text will be placed
        text_frame = Frame(self, width=WIDTH / 2)

        # the widget is a Tkinter Text
        # disable it by default
        # don't let the widget control the frame's size
        Game.text = Text(text_frame, bg="lightgrey", state=DISABLED)
        Game.text.pack(fill=Y, expand=1)
        text_frame.pack(side=RIGHT, fill=Y)
        text_frame.pack_propagate(False)

    # sets the current room image
    def setRoomImage(self):

        if (Game.currentRoom == None):
            # if dead, set the skull image
            Game.img = PhotoImage(file = "skull.gif")
        else:
            # otherwise grab the image for the current room
            Game.img = PhotoImage(file = Game.currentRoom.image)

        # display the image on the left of the GUI
        Game.image.config(image=Game.img)
        Game.image.image = Game.img

    # sets the status displayed on the right of the GUI
    def setStatus(self, status):

        # enable the text widget, clear it, set it, and disabled it
        Game.text.config(state=NORMAL)
        Game.text.delete("1.0", END)
        if (Game.currentRoom == None):
            # if dead, let the player know
            Game.text.insert(END, "You are dead. The only thing you can do now is quit.\n")
        else:
            # otherwise, display the appropriate status
            Game.text.insert(END, str(Game.currentRoom) +\
                    "\nYou are carrying: " + str(Game.inventory) +\
                    "\n\n" + status)
        Game.text.config(state = DISABLED)

    # plays the game
    def play(self):

        # add the rooms to the game
        self.createRooms()

        # configure the GUI
        self.setupGUI()
            
        # set the current room
        self.setRoomImage()

        # set the current status
        self.setStatus("")

    # processes the player's input
    def process(self, event):

        # grab the player's input from the input at the bottom of
        # the GUI
        action = Game.player_input.get()

        # set the user's input to lowercase to make it easier to
        # compare the verb and noun to known values
        action = action.lower()

        # set a default response
        response = "I don't understand. Try verb noun. Valid verbs are go, look, and take"

        # exit the game if the player wants to leave (supports quit,
        # exit, and bye)

        if (action == "quit" or action == "exit" or action == "bye"\
            or action == "sionara!"):
            exit(0)

        # if the player is dead if goes/went south from room 4
        if (Game.currentRoom == None):
            # clear the player's input
            Game.player_input.delete(0, END)
            return

        # split the user input into words (words are separated by
        # spaces) and store the words in a list
        words = action.split()
                                 
        # the game only understands two word inputs
        if (len(words) == 2):
            # isolate the verb and noun
            verb = words[0]
            noun = words[1]

        #The verb is enter ##############
        #if (verb == "enter"):

            #enter the randomizer
            #if (noun == "playhouse"):
                 
                
        
        
        #the verb is : use
        if (verb == "use"):

        #set a default response
            response = "You don't have one of those"

            if (noun in Game.inventory):
                response = "You can't use that."

                #if you use the key on the chest
                if(noun == "key"):
                    if (Game.currentRoom == Game.R3_1):
                        Game.inventory.remove("key")
                        Game.currentRoom = Game.R3_2

                        #change exits to point to this room
                        Game.R2.exits["east"] = Game.R3_2
                        Game.R4.exits["south"] = Game.R3_2
                    else:
                        response = "You can't use that here"

                #if you drink the vial you die... kind of.
                if(noun == "vial"):
                    Game.inventory.remove("vial")
                    Game.currentRoom = Game.DeathRoom2
                    # clear the players input
                    Game.player_input.delete(0,END)

                # You must have the biscuits to survive
                if(noun == "biscuits"):
                    Game.inventory.remove("biscuits")
                    Game.currentRoom = Game.R5_2
                    Game.R4_5.exits["east"] = Game.R5_2

                


        # the verb is: go
        if (verb == "go"):

            # set a default response
            response = "Invalid exit."

            # check for valid exits in the current room
            if (noun in Game.currentRoom.exits):

                # if one is found, change the current room to
                # the one that is associated with the
                # specified exit
                Game.currentRoom = Game.currentRoom.exits[noun]

                # set the response (success)
                response = "Room changed."

        # the verb is: look
        elif (verb == "look"):

            # set a default response
            response = "I don't see that item."

            # check for valid items in the current room
            if (noun in Game.currentRoom.items):

                # if one is found, set the response to the
                # item's description
                response = Game.currentRoom.items[noun]

                if (noun == "table"):

                    #Make the table lookable in room with key
                    #and only descriptive in room without key
                    if (Game.currentRoom == Game.R1):
                        Game.currentRoom = Game.R1_2
                        
                    elif (Game.currentRoom == Game.R1_3):
                        Game.currentRoom = Game.R1_4

                    elif (Game.currentRoom == Game.R4):
                        Game.currentRoom = Game.R4_1

                    elif (Game.currentRoom == Game.R7):
                        Game.currentRoom = Game.R7_1

                    else:
                        response = Game.currentRoom.items[noun]


                #zoom in when looking at the painting in room 1
                if (noun == "painting"):

                    #The rooms with the painting point back to
                    #different room 1's. 
                    if (Game.currentRoom == Game.R1):
                        Game.currentRoom = Game.R1_1

                    else:
                        Game.currentRoom = Game.R1

                #zoom in when looking at the arwork in room 6
                if (noun == "artwork"):
                    Game.currentRoom = Game.R6_4

                #zoom in when looking at the chest
                if (noun == "chest"):

                    #The rooms with the chest point back to
                    #different rooms
                    if (Game.currentRoom == Game.R3):
                        Game.currentRoom = Game.R3_1

                    else:
                        Game.currentRoom = Game.R3

                #zoom in when looking at the bookshelf 
                if (noun == "bookshelf"):

                    #The rooms with the bookshelf point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R4):
                        Game.currentRoom = Game.R4_3

                    else:
                        Game.currentRoom = Game.R4

                #zoom in when looking at the cages
                if (noun == "cages"):

                    #The rooms with the cages point back to
                    #different rooms
                    if (Game.currentRoom == Game.R4):
                        Game.currentRoom = Game.R4_2

                    else:
                        Game.currentRoom = Game.R4

                #zoom in when looking at the dog
                if (noun == "dog"):

                    #The rooms with the dog point back to
                    #different rooms.
                    if ("biscuits" in Game.inventory):
                        if (Game.currentRoom == Game.R5):
                            Game.currentRoom = Game.R5_1

                        else:
                            Game.currentRoom = Game.R5

                    else:
                        Game.currentRoom = Game.DeathRoom1

                #zoom in when looking at the rig
                if (noun == "rig"):

                    #The rooms with the rig point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R2):
                        Game.currentRoom = Game.R2_3

                    else:
                        Game.currentRoom = Game.R2

                #zoom in when looking at the desk
                if (noun == "desk"):

                    #The rooms with the desk point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R2):
                        Game.currentRoom = Game.R2_2

                    else:
                        Game.currentRoom = Game.R2

                #zoom in when looking at the bar
                if (noun == "bar"):

                    #The rooms with the bar point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R2):
                        Game.currentRoom = Game.R2_1

                    else:
                        Game.currentRoom = Game.R2

                 #zoom in when looking at the nightstand
                if (noun == "nightstand"):

                    
                    if (Game.currentRoom == Game.R6):
                        if ("biscuits" in Game.inventory):
                            Game.currentRoom = Game.R6_2
                        else:
                            Game.currentRoom = Game.R6_1

                    else:
                        Game.currentRoom = Game.R6

                 #zoom in when looking at the playhouse
                if (noun == "playhouse"):

                    #The rooms with the playhouse point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R6):
                        Game.currentRoom = Game.R6_3

                    else:
                        Game.currentRoom = Game.R6
                
                if (noun == "barrel"):

                    #The rooms with the barrel point back to
                    #different rooms. 
                    if (Game.currentRoom == Game.R7):
                        Game.currentRoom = Game.R7_2

                    else:
                        Game.currentRoom = Game.R7

        # the verb is: take
        elif (verb == "take"):

            # set a default response
            response = "I don't see that item."

            # check for valid grabbables items in the current
            # room
            for grabbables in Game.currentRoom.grabbables:

                # a valid grabbables item is found
                if (noun == grabbables):
                                        
                    # add the grabbables item to the player's
                    # inventory
                    Game.inventory.append(grabbables)

                    # remove the grabbables item from the room
                    Game.currentRoom.delGrabbables(grabbables)

                    # Taking key changes the room, no longer on table
                    if (noun == "key"):
                        Game.currentRoom = Game.R1_3
                        Game.R1.exits["east"] = Game.R3
                        Game.R1_3.exits["east"] = Game.R3
                        Game.R1.exits["north"] = Game.R2
                        Game.R1_3.exits["north"] = Game.R2

                        # Make sure other items are still viewable
                        Game.R1_1.exits["back"] = Game.R1_3
                        Game.R1_4.exits["back"] = Game.R1_3
                        
                        
                    # display room 7 without vial
                    if (noun == "vial"):
                        Game.currentRoom = Game.R7_4
                        Game.R6.exits["east"] = Game.R7_4
                        
                    # Display Room 6 without biscuits on table
                    if (noun == "biscuits"):
                        Game.currentRoom = Game.R6
                        Game.R6.items["nightstand"] = "It's an old wooden nightstand. There is nothing else here."

                     # Display Room without ink ribbon on shelf
                    if (noun == "ink_ribbon"):
                        Game.currentRoom = Game.R4_5
                        Game.R3.exits["north"] = Game.R4_5

                    if (noun == "potion"):
                        Game.currentRoom = Game.R5_3
                        Game.R4_5.exits["east"] = Game.R5_3
                        
                        


                    # set the response (success)
                    response = "Item grabbed."

                    # no need to check any more grabbables
                    # items
                    break
                                     
        # display the response on the right of the GUI
        # display the room's image on the left of the GUI
        # clear the player's input
        self.setStatus(response)
        self.setRoomImage()
        Game.player_input.delete(0, END)



##########################################################
# the default size of the GUI is 800x600
WIDTH = 800
HEIGHT = 600

# create the window
window = Tk()
window.title("Room Adventure")

# create the GUI as a Tkinter canvas inside the window
g = Game(window)
# play the game
g.play()

# wait for the window to close
window.mainloop()









